import React from 'react'


const UpdateDetails =()=>{
    const [firstName,setfirstName] = React.useState('');
    const [lastName,setlastName] = React.useState('');
    const [email,setemail] = React.useState('');
    const [bio,setbio] = React.useState('');
    const [image,setimage] = React.useState('');
    const [designation,setdesignation] = React.useState('');
    const [hashPassword,sethashPassword] = React.useState('');
    

      
    const params = useParams();
    const navigate = useNavigate();
    
    useEffect(()=>{
       console.warn(params);
       getProductDetails();
    },[])

    const getProductDetails = async ()=>{
        console.warn(params);
  
        fetch(`https://tempapi.proj.me/api/Bf9eJ.7Ov`)
        .then(response => response.json())
        .then(data => console.log(data));
        // result = await (await result).json()
        // console.warn(result);   
        // setfirstName(result.firstName)
        // setlastName(result.lastName)
        // setemail(result.email) 
        // setbio(result.bio)
        // setimage(result.image)
        // setdesignation(result.designation)
        // sethashPassword(result.hashPassword)
    }
    
    const updateProduct= async ()=>{
        //console.warn(name,price,category,company);
        let result = await fetch(`https://tempapi.proj.me/api/Bf9eJ.7Ov/${params.id}`,{
            method:"Put",
            body:JSON.stringify({
                firstName,lastName,email,bio,image,designation,hashPassword
            }),
            headers:{
                'Content-Type':"application/json"
            }
        });
        result = await result.json()
        console.warn(result);
        navigate("/");
    } 
  return (
    
    <div className="container">
    <div className="bg-white shadow rounded-lg d-block d-sm-flex">
    <div className="tab-content p-4 p-md-5" id="v-pills-tabContent">
      <div
        className="tab-pane fade show active"
        id="account"
        role="tabpanel"
        aria-labelledby="account-tab"
      >
        <h3 className="mb-4">Account Settings</h3>
        <div className="row">
          <div className="col-md-6">
            <div className="form-group">
              <label>First Name</label>
              <input type="text" className="form-control" value={firstName} onChange={(e)=>{setfirstName(e.target.value)}}/>
            </div>
          </div>
          <div className="col-md-6">
            <div className="form-group">
              <label>Last Name</label>
              <input type="text" className="form-control" value={lastName} onChange={(e)=>{setlastName(e.target.value)}}/>
            </div>
          </div>
          <div className="col-md-6">
            <div className="form-group">
              <label>Email</label>
              <input
                type="text"
                className="form-control"
                value={setemail}
                onChange={(e)=>{setemail(e.target.value)}}
              />
            </div>
          </div>
          <div className="col-md-6">
            <div className="form-group">
              <label>Image</label>
              <input type="text" className="form-control" value={image} onChange={(e)=>{setimage(e.target.value)}} />
            </div>
          </div>
          <div className="col-md-6">
            <div className="form-group">
              <label>Company</label>
              <input type="text" className="form-control" value="Xyz" />
            </div>
          </div>
          <div className="col-md-6">
            <div className="form-group">
              <label>Designation</label>
              <input type="text" className="form-control" value={designation} onChange={(e)=>{setimage(e.target.value)}} />
            </div>
          </div>
          <div className="col-md-12">
            <div className="form-group">
              <label>Bio</label>
              <textarea className="form-control" rows="4">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore
                vero enim error similique quia numquam ullam corporis officia
                odio repellendus aperiam consequatur laudantium porro
                voluptatibus, itaque laboriosam veritatis voluptatum distinctio!
              </textarea>
            </div>
          </div>
        </div>
        <div>
          <button onClick={updateProduct} className="btn btn-primary">Update</button>
          <button className="btn btn-light">Cancel</button>
        </div>
      </div>
    </div>
    </div>
    </div>
  )
}
export default UpdateDetails