import React, { useState, useRef, useEffect } from 'react';
import AccountDetails from './AccountDetails';
import ResetPassword from './ResetPassword';
// import { Link } from "react-router-dom";

function Nav() {
  const [component, setComponent] = useState('account');
      
  useEffect(()=>{
      getProductDetails();
  },[])

  const getProductDetails = async ()=>{
      fetch(`https://tempapi.proj.me/api/Bf9eJ.7Ov`)
      .then(response => response.json())
      .then(data => console.log(data));
  }
  const onLinkClick = (selectedComponent) => {
    setComponent(selectedComponent);
  }
  return (
    <div className="container">
      <div className="bg-white shadow rounded-lg d-block d-sm-flex">
        <div className="profile-tab-nav border-right">
          <div className="p-4">
            <div className="img-circle text-center mb-3">
              <img src="img/user2.jpg" alt="Image" className="shadow" />
            </div>
            <h4 className="text-center">Kiran Acharya</h4>
          </div>
          <div
            className="nav flex-column nav-pills"
            id="v-pills-tab"
            role="tablist"
            aria-orientation="vertical"
          >
            <a
              className="nav-link active"
              id="account-tab"
              data-toggle="pill"
              href="#account"
              role="tab"
              aria-controls="account"
              aria-selected="true"
              onClick={()=>{onLinkClick('account')}}
            >
              <i className="fa fa-home text-center mr-1"></i>
              Account
            </a>
            <a
              className="nav-link"
              id="password-tab"
              data-toggle="pill"
              href="#password"
              role="tab"
              aria-controls="password"
              aria-selected="false"
              onClick={()=>{onLinkClick('resetPassword')}}
            >
             <i className="fa fa-key text-center mr-1"></i>
             Password
            </a>
            <a
              className="nav-link"
              id="security-tab"
              data-toggle="pill"
              href="#security"
              role="tab"
              aria-controls="security"
              aria-selected="false"
            >
              <i className="fa fa-user text-center mr-1"></i>
              Security
            </a>
            <a
              className="nav-link"
              id="application-tab"
              data-toggle="pill"
              href="#application"
              role="tab"
              aria-controls="application"
              aria-selected="false"
            >
              <i className="fa fa-tv text-center mr-1"></i>
              Application
            </a>
            <a
              className="nav-link"
              id="notification-tab"
              data-toggle="pill"
              href="#notification"
              role="tab"
              aria-controls="notification"
              aria-selected="false"
            >
              <i class="fa fa-bell text-center mr-1"></i>
              Notification
            </a>
          </div>
        </div>
        <div>
          {component === 'account' ? 
          <AccountDetails/> : component === 'resetPassword' ?
        <ResetPassword/> : null}
        </div>
      </div>
    </div>
  );
}

export default Nav;
