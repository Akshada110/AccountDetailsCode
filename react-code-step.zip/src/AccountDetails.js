import React from "react";

function AccountDetails() {
  return (
    <div className="container">
    <div className="bg-white shadow rounded-lg d-block d-sm-flex">
    <div className="tab-content p-4 p-md-5" id="v-pills-tabContent">
      <div
        className="tab-pane fade show active"
        id="account"
        role="tabpanel"
        aria-labelledby="account-tab"
      >
        <h3 className="mb-4">Account Settings</h3>
        <div className="row">
          <div className="col-md-6">
            <div className="form-group">
              <label>First Name</label>
              <input type="text" className="form-control" value="Kiran" />
            </div>
          </div>
          <div className="col-md-6">
            <div className="form-group">
              <label>Last Name</label>
              <input type="text" className="form-control" value="Acharya" />
            </div>
          </div>
          <div className="col-md-6">
            <div className="form-group">
              <label>Email</label>
              <input
                type="text"
                className="form-control"
                value="kiranacharya287@gmail.com"
              />
            </div>
          </div>
          <div className="col-md-6">
            <div className="form-group">
              <label>Phone number</label>
              <input type="text" className="form-control" value="+91 9876543215" />
            </div>
          </div>
          <div className="col-md-6">
            <div className="form-group">
              <label>Company</label>
              <input type="text" className="form-control" value="Kiran Workspace" />
            </div>
          </div>
          <div className="col-md-6">
            <div className="form-group">
              <label>Designation</label>
              <input type="text" className="form-control" value="UI Developer" />
            </div>
          </div>
          <div className="col-md-12">
            <div className="form-group">
              <label>Bio</label>
              <textarea className="form-control" rows="4">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore
                vero enim error similique quia numquam ullam corporis officia
                odio repellendus aperiam consequatur laudantium porro
                voluptatibus, itaque laboriosam veritatis voluptatum distinctio!
              </textarea>
            </div>
          </div>
        </div>
        <div>
          <button className="btn btn-primary">Update</button>
          <button className="btn btn-light">Cancel</button>
        </div>
      </div>
    </div>
    </div>
    </div>
  


  );
}

export default AccountDetails;
