import React from 'react';
// import { BrowserRouter, Routes , Route } from "react-router-dom";
import Nav from './Nav';
import AccountDetails from './AccountDetails';
import ResetPassword from './ResetPassword';
import './style.css';

function App() {
  return (
    <div className="App">
   <Nav/>
   {/* <BrowserRouter> 
    <Routes> 
    <Route path="/" element={<ResetPassword/>} />,
    </Routes>

    </BrowserRouter> */}
    </div>
  )
}

export default App